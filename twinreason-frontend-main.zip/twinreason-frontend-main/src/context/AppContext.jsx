// src/context/AppContext.jsx
// ─────────────────────────────────────────────────────────────────
// Global App State
//
// Stores: selectedUser, locale (en-US or en-NG)
// Any component can access these by calling: useApp()
//
// Example usage in any component:
//   import { useApp } from "../context/AppContext";
//   const { selectedUser, locale, changeUser, toggleLocale } = useApp();
// ─────────────────────────────────────────────────────────────────

import { createContext, useContext, useState } from "react";
import { MOCK_USERS } from "../api/mockData";

// Step 1: Create the context object (starts empty, AppProvider fills it)
const AppContext = createContext(null);

/**
 * AppProvider
 * Wrap your whole app with this so every component can access global state.
 * It lives in main.jsx wrapping everything.
 */
export function AppProvider({ children }) {
  // Start with Amaka selected by default (first user in the list)
  const [selectedUser, setSelectedUser] = useState(MOCK_USERS[0]);

  // Start with English locale
  const [locale, setLocale] = useState("en-US");

  /**
   * toggleLocale
   * Switches between English and Nigerian Pidgin
   * Called when the user clicks the Naija toggle button in the header
   */
  function toggleLocale() {
    setLocale((prev) => (prev === "en-US" ? "en-NG" : "en-US"));
  }

  /**
   * changeUser
   * Switches the active user by their ID
   * Called when the user picks a different person from the header dropdown
   *
   * @param {string} userId - e.g. "U_amaka"
   */
  function changeUser(userId) {
    const user = MOCK_USERS.find((u) => u.id === userId);
    if (user) setSelectedUser(user);
  }

  // Everything components can access via useApp()
  const value = {
    selectedUser,       // the full user object currently selected
    locale,             // "en-US" or "en-NG"
    isNaija: locale === "en-NG",  // shortcut boolean for Naija mode
    changeUser,         // function to switch users
    toggleLocale,       // function to toggle language
    allUsers: MOCK_USERS, // full list for the dropdown
  };

  return (
    <AppContext.Provider value={value}>
      {children}
    </AppContext.Provider>
  );
}

/**
 * useApp
 * Custom hook — use this in any component to access global state
 * Throws a helpful error if used outside AppProvider
 */
export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error("useApp must be used inside AppProvider");
  }
  return context;
}