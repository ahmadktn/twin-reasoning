// src/pages/HomeFeed.jsx
// ─────────────────────────────────────────────────────────────────
// Home Feed — Page 1 (route: /)
//
// What happens here:
// 1. Page loads → shows skeleton grid immediately
// 2. Calls Task A for all 12 items in parallel
// 3. Replaces skeletons with real cards when data arrives
// 4. Re-fetches everything when user or locale changes
// ─────────────────────────────────────────────────────────────────

import { useState, useEffect } from "react";
import {
  Box,
  Container,
  Heading,
  Text,
  SimpleGrid,
  Button,
  Alert,
  AlertIcon,
  AlertTitle,
  AlertDescription,
  VStack,
  HStack,
  Badge,
  Select,
  useColorModeValue,
} from "@chakra-ui/react";
import { useApp } from "../context/AppContext";
import { simulateReviewBatch } from "../api/taskA";
import { MOCK_ITEMS } from "../api/mockData";
import ItemCard from "../components/ItemCard";
import { SkeletonGrid } from "../components/LoadingSkeleton";

// All category filter options
const CATEGORIES = ["All", "Restaurant", "Book", "Music", "Movie", "Product"];

export default function HomeFeed() {
  const { selectedUser, locale, isNaija } = useApp();

  // All items from mock data
  const [items] = useState(MOCK_ITEMS);

  // reviews — maps item.id → review result from API
  const [reviews, setReviews]       = useState({});
  const [loading, setLoading]       = useState(true);
  const [error, setError]           = useState(null);

  // Active category filter
  const [activeCategory, setActiveCategory] = useState("All");

  const headingColor  = useColorModeValue("gray.800", "gray.100");
  const subTextColor  = useColorModeValue("gray.500", "gray.400");
  const filterBg      = useColorModeValue("white", "#1E1E1E");
  const filterBorder  = useColorModeValue("gray.200", "gray.700");

  // ── Load reviews whenever user or locale changes ───────────────
  useEffect(() => {
    async function loadReviews() {
      setLoading(true);
      setError(null);

      try {
        // Fetch reviews for ALL items in parallel (not one by one)
        const results = await simulateReviewBatch(
          selectedUser.id,
          items,
          locale
        );

        // Convert array of results into a map: { "I_001": reviewData, ... }
        const reviewMap = {};
        items.forEach((item, index) => {
          reviewMap[item.id] = results[index];
        });

        setReviews(reviewMap);
      } catch (err) {
        console.error("Failed to load reviews:", err);
        setError(
          "Could not load reviews. The AI service may be offline."
        );
      } finally {
        setLoading(false);
      }
    }

    loadReviews();
  }, [selectedUser.id, locale]); // re-runs when user or locale changes

  // ── Filter items by selected category ─────────────────────────
  const filteredItems =
    activeCategory === "All"
      ? items
      : items.filter((item) => item.category === activeCategory);

  return (
    <Container maxW="1280px" py={8} px={{ base: 4, md: 8 }}>

      {/* ── Page Header ─────────────────────────────────────── */}
      <VStack align="start" spacing={1} mb={6}>
        <HStack spacing={3} align="center">
          <Heading size="lg" color={headingColor}>
            {isNaija
              ? `Your Feed, ${selectedUser.name.split(" ")[0]} 🇳🇬`
              : `Your Feed, ${selectedUser.name.split(" ")[0]}`}
          </Heading>
          {selectedUser.coldStart && (
            <Badge colorScheme="orange" borderRadius="full" px={3}>
              Cold Start
            </Badge>
          )}
        </HStack>
        <Text color={subTextColor} fontSize="sm">
          {isNaija
            ? "Your Digital Twin dey write reviews for you — Naija style 🔥"
            : "Personalised reviews and recommendations from your Digital Twin"}
        </Text>
      </VStack>

      {/* ── Category Filter Row ──────────────────────────────── */}
      <Box
        mb={6}
        pb={4}
        borderBottom="1px solid"
        borderColor={filterBorder}
      >
        <HStack spacing={2} wrap="wrap">
          {CATEGORIES.map((cat) => (
            <Button
              key={cat}
              size="sm"
              borderRadius="full"
              variant={activeCategory === cat ? "solid" : "outline"}
              colorScheme={activeCategory === cat ? "brand" : "gray"}
              onClick={() => setActiveCategory(cat)}
              fontWeight={activeCategory === cat ? "600" : "400"}
            >
              {cat}
            </Button>
          ))}
        </HStack>
      </Box>

      {/* ── Error Banner ─────────────────────────────────────── */}
      {error && (
        <Alert status="error" borderRadius="xl" mb={6}>
          <AlertIcon />
          <AlertTitle>Connection Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* ── Item Grid ────────────────────────────────────────── */}
      {loading ? (
        // Show skeletons while loading
        <SkeletonGrid count={12} />
      ) : (
        <>
          {/* Results count */}
          <Text fontSize="sm" color={subTextColor} mb={4}>
            Showing {filteredItems.length} items
            {activeCategory !== "All" && ` in ${activeCategory}`}
          </Text>

          {/* Real item cards */}
          <SimpleGrid
            columns={{ base: 1, sm: 2, md: 3, lg: 4 }}
            spacing={4}
          >
            {filteredItems.map((item) => (
              <ItemCard
                key={item.id}
                item={item}
                review={reviews[item.id]}
              />
            ))}
          </SimpleGrid>

          {/* Empty state when filter has no results */}
          {filteredItems.length === 0 && (
            <VStack py={16} spacing={3}>
              <Text fontSize="2xl"></Text>
              <Text color={subTextColor}>
                No items in this category yet.
              </Text>
              <Button
                size="sm"
                variant="outline"
                onClick={() => setActiveCategory("All")}
              >
                Show all
              </Button>
            </VStack>
          )}
        </>
      )}

      {/* ── Load More ────────────────────────────────────────── */}
      {!loading && filteredItems.length > 0 && (
        <Box textAlign="center" mt={10}>
          <Button variant="outline" colorScheme="gray" size="md">
            Load more
          </Button>
        </Box>
      )}

    </Container>
  );
}