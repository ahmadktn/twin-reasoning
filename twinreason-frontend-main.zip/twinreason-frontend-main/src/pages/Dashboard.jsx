// src/pages/Dashboard.jsx
// ─────────────────────────────────────────────────────────────────
// Twin Dashboard — Page 4 (route: /dashboard)
//
// Shows the user's Digital Twin profile:
// - How many reviews it was trained on
// - Average rating tendency
// - Writing style summary
// - Rating bias
// - Adapter type (personal vs population baseline)
// - Cold start progress
// ─────────────────────────────────────────────────────────────────

import {
  Container,
  Heading,
  VStack,
  HStack,
  Text,
  Badge,
  SimpleGrid,
  Box,
  Progress,
  Divider,
  Alert,
  AlertIcon,
  useColorModeValue,
} from "@chakra-ui/react";
import { useApp } from "../context/AppContext";

export default function Dashboard() {
  const { selectedUser, isNaija } = useApp();

  const cardBg      = useColorModeValue("white", "#1E1E1E");
  const borderColor = useColorModeValue("gray.200", "gray.700");
  const metaColor   = useColorModeValue("gray.500", "gray.400");
  const textColor   = useColorModeValue("gray.700", "gray.200");

  // Determine if the bias is positive or negative
  const biasDirection =
    selectedUser.ratingBias > 0
      ? "higher"
      : selectedUser.ratingBias < 0
      ? "lower"
      : "neutral";

  const biasMagnitude = Math.abs(selectedUser.ratingBias || 0).toFixed(1);

  return (
    <Container maxW="900px" py={8} px={{ base: 4, md: 8 }}>

      {/* ── Page Header ─────────────────────────────────────── */}
      <VStack align="start" spacing={1} mb={8}>
        <HStack spacing={3} align="center">
          <Heading size="lg">Your Digital Twin</Heading>
          {selectedUser.coldStart && (
            <Badge colorScheme="orange" borderRadius="full" px={3}>
              Still Learning
            </Badge>
          )}
          {isNaija && (
            <Badge colorScheme="orange" borderRadius="full" px={3}>
              🇳🇬 Naija Mode
            </Badge>
          )}
        </HStack>
        <Text color={metaColor} fontSize="sm">
          This is your personal AI twin trained on your review history.
          Everything here is learned from your past interactions.
        </Text>
      </VStack>

      {/* ── Cold Start Alert ─────────────────────────────────── */}
      {selectedUser.coldStart && (
        <Alert
          status="info"
          borderRadius="xl"
          mb={8}
          bg="orange.50"
          _dark={{ bg: "orange.900" }}
        >
          <AlertIcon />
          <VStack align="start" spacing={1} w="100%">
            <Text fontWeight="600" fontSize="sm">
              Your twin is still learning
            </Text>
            <Text fontSize="xs" color={metaColor}>
              After 5 more reviews, your twin will become fully personalised and
              write reviews in your unique voice.
            </Text>
            <Progress
              value={0}
              max={5}
              size="sm"
              borderRadius="full"
              mt={2}
              w="100%"
            />
          </VStack>
        </Alert>
      )}

      {/* ── Stats Grid ──────────────────────────────────────── */}
      <SimpleGrid columns={{ base: 2, md: 4 }} spacing={4} mb={8}>
        {/* Reviews trained on */}
        <StatCard
          label="Reviews trained on"
          value={selectedUser.reviewCount}
          icon=""
        />

        {/* Average rating */}
        <StatCard
          label="Average rating"
          value={
            selectedUser.avgRating
              ? selectedUser.avgRating.toFixed(1)
              : "N/A"
          }
          icon=""
        />

        {/* Adapter type */}
        <StatCard
          label="Adapter type"
          value={
            selectedUser.adapterType === "user_adapter"
              ? "Personal"
              : "Baseline"
          }
          icon=""
        />

        {/* Platforms */}
        <StatCard
          label="Trained on"
          value={selectedUser.platform}
          isSmall
          icon=""
        />
      </SimpleGrid>

      <Divider mb={8} />

      {/* ── Writing Style Section ────────────────────────────– */}
      <VStack align="start" spacing={3} mb={8}>
        <Heading size="sm">Writing Style</Heading>
        {selectedUser.styleSummary ? (
          <Box
            bg={cardBg}
            borderRadius="xl"
            border="1px solid"
            borderColor={borderColor}
            p={5}
            borderLeft="4px solid"
            borderLeftColor="brand.500"
          >
            <Text lineHeight="1.8" color={textColor}>
              {selectedUser.styleSummary}
            </Text>
          </Box>
        ) : (
          <Text color={metaColor} fontSize="sm">
            No style summary yet — your twin needs more reviews to learn your
            unique writing voice.
          </Text>
        )}
      </VStack>

      {/* ── Rating Bias Section ─────────────────────────────── */}
      {selectedUser.ratingBias !== null && (
        <VStack align="start" spacing={3} mb={8}>
          <Heading size="sm">Rating Tendency</Heading>
          <Box
            bg={cardBg}
            borderRadius="xl"
            border="1px solid"
            borderColor={borderColor}
            p={5}
            w="100%"
          >
            <HStack justify="space-between" mb={3}>
              <Text fontWeight="500" fontSize="sm">
                You rate {biasDirection}
              </Text>
              <Badge
                colorScheme={
                  selectedUser.ratingBias > 0
                    ? "green"
                    : selectedUser.ratingBias < 0
                    ? "orange"
                    : "gray"
                }
                fontSize="sm"
                px={3}
              >
                {biasMagnitude} stars {biasDirection}
              </Badge>
            </HStack>
            <Progress
              value={Math.min(selectedUser.ratingBias * 2 + 2, 5)}
              max={5}
              borderRadius="full"
              size="sm"
              colorScheme={
                selectedUser.ratingBias > 0
                  ? "green"
                  : selectedUser.ratingBias < 0
                  ? "orange"
                  : "gray"
              }
            />
            <Text fontSize="xs" color={metaColor} mt={3}>
              The average user rates around 3.5 stars. Your twin learned this
              pattern from your review history.
            </Text>
          </Box>
        </VStack>
      )}

      {/* ── Adapter Info ─────────────────────────────────────– */}
      <VStack align="start" spacing={3}>
        <Heading size="sm">Adapter Details</Heading>
        <Box
          bg={cardBg}
          borderRadius="xl"
          border="1px solid"
          borderColor={borderColor}
          p={5}
          w="100%"
        >
          <HStack mb={3}>
            <Badge colorScheme="blue" borderRadius="full" px={3}>
              {selectedUser.adapterType}
            </Badge>
            <Text fontWeight="600" fontSize="sm">
              {selectedUser.adapterType === "user_adapter"
                ? "Personal Twin"
                : "Population Baseline"}
            </Text>
          </HStack>
          <Text fontSize="sm" color={textColor} lineHeight="1.7">
            {selectedUser.adapterType === "user_adapter"
              ? "This adapter was fine-tuned on your personal review history. It understands your unique writing voice, rating patterns, and preferences. The more reviews you submit, the more accurate it becomes."
              : "This is the population baseline model. It represents average user behavior. You have not submitted enough reviews yet for a personal adapter to be trained."}
          </Text>
        </Box>
      </VStack>

    </Container>
  );
}

// ── Sub-component: stat card ────────────────────────────────────
function StatCard({ label, value, icon, isSmall = false }) {
  const cardBg      = useColorModeValue("white", "#1E1E1E");
  const borderColor = useColorModeValue("gray.200", "gray.700");
  const metaColor   = useColorModeValue("gray.500", "gray.400");

  return (
    <Box
      bg={cardBg}
      borderRadius="xl"
      border="1px solid"
      borderColor={borderColor}
      p={4}
      textAlign="center"
      transition="all 0.2s"
      _hover={{ shadow: "sm", borderColor: "brand.300" }}
    >
      <Text fontSize="2xl" mb={2}>
        {icon}
      </Text>
      <Text fontSize="10px" color={metaColor} textTransform="uppercase" mb={1}>
        {label}
      </Text>
      <Text fontSize={isSmall ? "xs" : "xl"} fontWeight="600">
        {value}
      </Text>
    </Box>
  );
}