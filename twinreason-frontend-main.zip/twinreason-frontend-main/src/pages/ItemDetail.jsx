// src/pages/ItemDetail.jsx
// ─────────────────────────────────────────────────────────────────
// Item Detail — Page 2 (route: /item/:itemId)
//
// What happens here:
// 1. Reads itemId from the URL
// 2. Finds the item from MOCK_ITEMS
// 3. Calls Task A to generate a FULL review
// 4. "Compare with" dropdown re-fetches for a different user
//    without changing the global selected user
// ─────────────────────────────────────────────────────────────────

import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  Box,
  Container,
  VStack,
  HStack,
  Heading,
  Text,
  Badge,
  Button,
  Select,
  Divider,
  Alert,
  AlertIcon,
  Skeleton,
  SkeletonText,
  Flex,
  Tooltip,
  useColorModeValue,
} from "@chakra-ui/react";
import { ArrowBackIcon, TimeIcon } from "@chakra-ui/icons";
import { useApp } from "../context/AppContext";
import { simulateReview } from "../api/taskA";
import { MOCK_ITEMS, MOCK_USERS } from "../api/mockData";
import StarRating from "../components/StarRating";

export default function ItemDetail() {
  // Get itemId from the URL — e.g. /item/I_001 → itemId = "I_001"
  const { itemId } = useParams();
  const navigate   = useNavigate();
  const { selectedUser, locale, isNaija, allUsers } = useApp();

  // Find the item from our catalogue
  const item = MOCK_ITEMS.find((i) => i.id === itemId);

  // Review data from the API
  const [review, setReview]   = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState(null);

  // The user shown in the compare dropdown
  // Starts as the globally selected user
  const [compareUserId, setCompareUserId] = useState(selectedUser.id);

  // Colors
  const cardBg       = useColorModeValue("gray.50", "#1E1E1E");
  const borderColor  = useColorModeValue("gray.200", "gray.700");
  const tagBg        = useColorModeValue("white", "gray.700");
  const metaColor    = useColorModeValue("gray.500", "gray.400");
  const reviewTextColor = useColorModeValue("gray.700", "gray.200");

  // ── Fetch review when compareUserId or locale changes ─────────
  useEffect(() => {
    if (!item) return;

    async function loadReview() {
      setLoading(true);
      setError(null);
      try {
        const result = await simulateReview(compareUserId, item, locale);
        setReview(result);
      } catch (err) {
        console.error("Failed to load review:", err);
        setError("Could not load review. Try again.");
      } finally {
        setLoading(false);
      }
    }

    loadReview();
  }, [compareUserId, locale, itemId]);

  // ── Update compareUserId when global user changes ─────────────
  useEffect(() => {
    setCompareUserId(selectedUser.id);
  }, [selectedUser.id]);

  // ── Item not found ─────────────────────────────────────────────
  if (!item) {
    return (
      <Container maxW="800px" py={8}>
        <Alert status="error" borderRadius="xl">
          <AlertIcon />
          Item not found. It may have been removed.
        </Alert>
        <Button mt={4} onClick={() => navigate("/")} leftIcon={<ArrowBackIcon />}>
          Back to Feed
        </Button>
      </Container>
    );
  }

  // Get the full user object for whoever is in the compare dropdown
  const reviewingUser = MOCK_USERS.find((u) => u.id === compareUserId);

  // Badge colour based on adapter type
  function adapterColor(adapter) {
    if (adapter === "user_adapter")       return "teal";
    if (adapter === "population_adapter") return "orange";
    return "gray";
  }

  // Badge label
  function adapterLabel(adapter) {
    if (adapter === "user_adapter")       return "Personal Twin";
    if (adapter === "population_adapter") return "Population Baseline";
    return adapter;
  }

  return (
    <Container maxW="860px" py={8} px={{ base: 4, md: 8 }}>

      {/* ── Back Button ─────────────────────────────────────── */}
      <Button
        leftIcon={<ArrowBackIcon />}
        variant="ghost"
        size="sm"
        mb={6}
        color="gray.500"
        onClick={() => navigate(-1)}
        _hover={{ color: "brand.500" }}
      >
        Back to Feed
      </Button>

      {/* ── Item Header ─────────────────────────────────────── */}
      <HStack spacing={5} align="start" mb={8}>
        {/* Emoji block */}
        <Flex
          w="90px"
          h="90px"
          flexShrink={0}
          bg={cardBg}
          borderRadius="2xl"
          border="1px solid"
          borderColor={borderColor}
          align="center"
          justify="center"
          fontSize="3xl"
        >
          {item.emoji}
        </Flex>

        {/* Item info */}
        <VStack align="start" spacing={2} flex={1}>
          <Heading size="lg">{item.title}</Heading>
          <Text color={metaColor} fontSize="sm">
            {item.description}
          </Text>
          {/* Category tags */}
          <HStack wrap="wrap" spacing={2}>
            {item.tags.map((tag) => (
              <Badge
                key={tag}
                px={3}
                py={1}
                borderRadius="full"
                fontSize="xs"
                fontWeight="500"
                bg={tagBg}
                border="1px solid"
                borderColor={borderColor}
                // Green for Nigerian/African cultural tags
                colorScheme={
                  tag.includes("Nigerian") ||
                  tag.includes("Naija") ||
                  tag.includes("Afro") ||
                  tag.includes("Nollywood")
                    ? "green"
                    : "gray"
                }
              >
                {tag.replace(/_/g, " ")}
              </Badge>
            ))}
          </HStack>
        </VStack>
      </HStack>

      <Divider mb={6} />

      {/* ── Review Section Header ────────────────────────────── */}
      <HStack
        justify="space-between"
        align="center"
        mb={4}
        wrap="wrap"
        gap={3}
      >
        {/* Left: whose review + badges */}
        <HStack spacing={2} wrap="wrap">
          <Text fontWeight="600" fontSize="sm">
            {reviewingUser?.name}'s Twin Review
          </Text>
          {review && !loading && (
            <Tooltip
              label="Which AI model generated this review"
              hasArrow
              fontSize="xs"
            >
              <Badge
                colorScheme={adapterColor(review.adapter_used)}
                borderRadius="full"
                px={3}
                fontSize="xs"
                cursor="help"
              >
                {adapterLabel(review.adapter_used)}
              </Badge>
            </Tooltip>
          )}
          {isNaija && (
            <Badge colorScheme="orange" borderRadius="full" px={3} fontSize="xs">
              🇳🇬 Naija
            </Badge>
          )}
        </HStack>

        {/* Right: compare dropdown */}
        <HStack spacing={2}>
          <Text fontSize="xs" color={metaColor} whiteSpace="nowrap">
            Compare with:
          </Text>
          <Select
            size="sm"
            value={compareUserId}
            onChange={(e) => setCompareUserId(e.target.value)}
            w="165px"
            borderRadius="lg"
            _focus={{ borderColor: "brand.500" }}
          >
            {allUsers.map((u) => (
              <option key={u.id} value={u.id}>
                {u.name}
              </option>
            ))}
          </Select>
        </HStack>
      </HStack>

      {/* ── Review Card ──────────────────────────────────────── */}
      <Box
        bg={cardBg}
        borderRadius="2xl"
        p={6}
        borderLeft="4px solid"
        borderColor="brand.500"
        border="1px solid"
        borderLeftWidth="4px"
        borderLeftColor="brand.500"
        borderTopColor={borderColor}
        borderRightColor={borderColor}
        borderBottomColor={borderColor}
        mb={6}
        minH="160px"
      >
        {loading ? (
          // Skeleton while review loads
          <VStack align="start" spacing={4}>
            <Skeleton height="28px" width="140px" borderRadius="md" />
            <SkeletonText noOfLines={4} spacing={3} w="100%" />
            <Skeleton height="16px" width="120px" />
          </VStack>
        ) : error ? (
          <Alert status="error" borderRadius="xl">
            <AlertIcon />
            {error}
          </Alert>
        ) : (
          <VStack align="start" spacing={4}>
            {/* Star rating — large size */}
            <StarRating rating={review?.rating} size="lg" />

            {/* Full review text */}
            <Text
              fontSize="md"
              lineHeight="1.9"
              fontStyle="italic"
              color={reviewTextColor}
            >
              "{review?.review_text}"
            </Text>
            <HStack spacing={3} fontSize="xs" color={metaColor}>
                 <Text> Generated in {review?.inference_ms}ms</Text>
                <Text>•</Text>
                <Text>{review?.adapter_used === "user_adapter" ? "Personal Twin" : "Population Baseline"}</Text>
            </HStack>
            {/* Meta info */}
            <HStack spacing={4}>
              <HStack spacing={1} color={metaColor}>
                <TimeIcon boxSize={3} />
                <Text fontSize="xs">
                  Generated in {review?.inference_ms}ms
                </Text>
              </HStack>
              {review?.is_naija && (
                <Text fontSize="xs" color="orange.400">
                  🇳🇬 Written in Nigerian Pidgin
                </Text>
              )}
            </HStack>
          </VStack>
        )}
      </Box>

      {/* ── Action Buttons ───────────────────────────────────── */}
      <HStack spacing={3} wrap="wrap">
        <Button
          colorScheme="brand"
          size="md"
          borderRadius="xl"
          onClick={() =>
            navigate(
              `/chat?item=${item.id}&title=${encodeURIComponent(item.title)}`
            )
          }
        >
          Ask your twin about this →
        </Button>
        <Button
          variant="outline"
          colorScheme="gray"
          size="md"
          borderRadius="xl"
          onClick={() => navigate("/")}
        >
          Back to Feed
        </Button>
      </HStack>

    </Container>
  );
}