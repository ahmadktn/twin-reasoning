// src/api/taskB.js
// ─────────────────────────────────────────────────────────────────
// Track B API — Conversational Recommendations
//
// Two functions:
// 1. createSession() — call once when chat page loads
// 2. sendMessage()   — call every time user sends a message
//
// When VITE_USE_MOCK=true  → returns fake data from mockData.js
// When VITE_USE_MOCK=false → calls the real AI backend
// ─────────────────────────────────────────────────────────────────

import { MOCK_CHAT_RESPONSES } from "./mockData";

const USE_MOCK = import.meta.env.VITE_USE_MOCK === "true";
const TASK_B_URL = import.meta.env.VITE_TASK_B_URL || "http://localhost:8002";

/**
 * createSession
 * Starts a new chat session for a user.
 * IMPORTANT: Save the returned session_id to localStorage immediately.
 *
 * @param {string} userId  - e.g. "U_amaka"
 * @returns {object}       - { session_id: "S_abc123" }
 */
export async function createSession(userId) {
  if (USE_MOCK) {
    await delay(400);
    // Generate a unique mock session id using userId + timestamp
    return { session_id: `mock_session_${userId}_${Date.now()}` };
  }

  const response = await fetch(`${TASK_B_URL}/api/v1/recommend/session`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ user_id: userId }),
  });

  if (!response.ok) {
    throw new Error(`Task B session error: ${response.status}`);
  }

  return response.json();
}

/**
 * sendMessage
 * Sends the user's chat message and gets back a response + recommendations
 *
 * @param {string} sessionId  - the session_id from createSession()
 * @param {string} message    - the user's typed message
 * @returns {object}          - { agent_response, recommendations, intent, turn_count }
 */
export async function sendMessage(sessionId, message) {
  if (USE_MOCK) {
    // Longer delay here to simulate AI thinking time
    await delay(1200);

    // Rotate through mock responses so the chat feels dynamic
    const index = Math.floor(Math.random() * MOCK_CHAT_RESPONSES.length);
    return MOCK_CHAT_RESPONSES[index];
  }

  const response = await fetch(`${TASK_B_URL}/api/v1/recommend/message`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      session_id: sessionId,
      message: message,
    }),
  });

  if (!response.ok) {
    throw new Error(`Task B message error: ${response.status}`);
  }

  return response.json();
}

// ── Helper ────────────────────────────────────────────────────────
function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}