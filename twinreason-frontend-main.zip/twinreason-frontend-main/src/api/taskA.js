// src/api/taskA.js
// ─────────────────────────────────────────────────────────────────
// Track A API — Review Simulation
//
// When VITE_USE_MOCK=true  → returns fake data from mockData.js
// When VITE_USE_MOCK=false → calls the real AI backend
//
// TO SWITCH TO REAL API: change VITE_USE_MOCK=false in .env
// No other code changes needed.
// ─────────────────────────────────────────────────────────────────

import { MOCK_REVIEWS, getDefaultMockReview } from "./mockData";

const USE_MOCK = import.meta.env.VITE_USE_MOCK === "true";
const TASK_A_URL = import.meta.env.VITE_TASK_A_URL || "http://localhost:8001";

/**
 * simulateReview
 * Generates a review for one user + one item
 *
 * @param {string} userId  - e.g. "U_amaka"
 * @param {object} item    - full item object from MOCK_ITEMS
 * @param {string} locale  - "en-US" or "en-NG" (Naija mode)
 * @returns {object}       - { rating, review_text, adapter_used, is_naija, inference_ms }
 */
export async function simulateReview(userId, item, locale = "en-US") {
  // ── MOCK MODE ──────────────────────────────────────────────────
  if (USE_MOCK) {
    // Small delay so loading skeletons are visible (feels realistic)
    await delay(800);

    const isNaija = locale === "en-NG";
    const key = `${userId}_${item.id}`;

    // Return specific mock review if it exists, otherwise return default
    return MOCK_REVIEWS[key] || getDefaultMockReview(userId, item.id, isNaija);
  }

  // ── REAL API MODE ──────────────────────────────────────────────
  const response = await fetch(`${TASK_A_URL}/api/v1/review/simulate`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      user_id: userId,
      item_id: item.id,
      item_title: item.title,
      item_description: item.description,
      category: item.category,
      locale: locale,
    }),
  });

  if (!response.ok) {
    throw new Error(
      `Task A API error: ${response.status} ${response.statusText}`
    );
  }

  return response.json();
}

/**
 * simulateReviewBatch
 * Generates reviews for ALL items at the same time (parallel)
 * Used on the Home Feed to load all cards at once instead of one by one
 *
 * @param {string} userId
 * @param {Array}  items   - array of item objects
 * @param {string} locale
 * @returns {Array}        - array of review results, same order as items
 */
export async function simulateReviewBatch(userId, items, locale = "en-US") {
  const promises = items.map((item) => simulateReview(userId, item, locale));
  return Promise.all(promises);
}

// ── Helper ────────────────────────────────────────────────────────
function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}