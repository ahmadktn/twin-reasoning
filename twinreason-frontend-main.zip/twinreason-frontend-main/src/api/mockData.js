// src/api/mockData.js
// ─────────────────────────────────────────────────────────────────
// MOCK DATA — Used when VITE_USE_MOCK=true in your .env file
// This data mimics exactly what the real AI APIs will return.
// When the backend is ready, set VITE_USE_MOCK=false and this file
// is no longer used. Nothing else in your code needs to change.
// ─────────────────────────────────────────────────────────────────

// Category colour scheme — used in ItemCard and HomeFeed
export const CATEGORY_COLORS = {
  "Restaurant": "orange",
  "Book": "blue",
  "Music": "purple",
  "Movie": "red",
  "Product": "gray",
};

export const MOCK_USERS = [
  {
    id: "U_amaka",
    name: "Amaka Okonkwo",
    avatar: "AO",
    platform: "Yelp + Amazon",
    reviewCount: 47,
    avgRating: 4.1,
    isNigerian: true,
    adapterType: "user_adapter",
    styleSummary:
      "You prefer spicy, local food and write short punchy reviews. You tend to comment on service speed and value for money. Your writing is direct with occasional humour — and you rate about 0.3 stars lower than average.",
    ratingBias: -0.3,
    coldStart: false,
  },
  {
    id: "U_chidi",
    name: "Chidi Nwosu",
    avatar: "CN",
    platform: "Goodreads + Yelp",
    reviewCount: 33,
    avgRating: 3.8,
    isNigerian: true,
    adapterType: "user_adapter",
    styleSummary:
      "You are a detailed reviewer who writes long, analytical reviews. You frequently comment on atmosphere and presentation. You rate books higher than restaurants.",
    ratingBias: -0.6,
    coldStart: false,
  },
  {
    id: "U_john",
    name: "John Davies",
    avatar: "JD",
    platform: "Amazon",
    reviewCount: 21,
    avgRating: 4.4,
    isNigerian: false,
    adapterType: "user_adapter",
    styleSummary:
      "You write concise, practical reviews focused on value for money. You rarely give below 3 stars and tend to be generous with praise.",
    ratingBias: 0.1,
    coldStart: false,
  },
  {
    id: "U_cold",
    name: "New User",
    avatar: "NU",
    platform: "None yet",
    reviewCount: 0,
    avgRating: null,
    isNigerian: false,
    adapterType: "population_adapter",
    styleSummary: null,
    ratingBias: null,
    coldStart: true,
  },
];

export const MOCK_ITEMS = [
  {
    id: "I_001",
    title: "Mama Put Lagos",
    category: "Restaurant",
    description: "Authentic Nigerian home cooking in the heart of Lagos",
    tags: ["Nigerian_cuisine", "Affordable", "Local"],
    emoji: "🍲",
    imageQuery: "nigerian jollof rice food",
  },
  {
    id: "I_002",
    title: "Purple Hibiscus",
    category: "Book",
    description: "A novel by Chimamanda Ngozi Adichie about family and faith",
    tags: ["Nigerian_literature", "Drama", "Award-winning"],
    emoji: "",
    imageQuery: "african literature book reading",
  },
  {
    id: "I_003",
    title: "Afrobeats Mix Vol. 3",
    category: "Music",
    description: "A curated mix of the best Afrobeats tracks this year",
    tags: ["Afrobeats", "Nigerian_music", "Dance"],
    emoji: "",
    imageQuery: "afrobeats music concert africa",
  },
  {
    id: "I_004",
    title: "AirPods Pro 2",
    category: "Product",
    description: "Apple's premium noise-cancelling wireless earphones",
    tags: ["Tech", "Audio", "Premium"],
    emoji: "",
    imageQuery: "airpods headphones white earbuds",
  },
  {
    id: "I_005",
    title: "Buka Suya Spot",
    category: "Restaurant",
    description: "Famous grilled meat and suya spot in Abuja",
    tags: ["Nigerian_cuisine", "Grilled", "Street_food"],
    emoji: "",
    imageQuery: "grilled meat suya nigerian street food",
  },
  {
    id: "I_006",
    title: "Omo Ghetto",
    category: "Movie",
    description: "A Nigerian comedy film about street life in Lagos",
    tags: ["Nollywood", "Comedy", "Nigerian_film"],
    emoji: "",
    imageQuery: "nollywood movie film africa cinema",
  },
  {
    id: "I_007",
    title: "Things Fall Apart",
    category: "Book",
    description: "Chinua Achebe's classic novel about pre-colonial Nigeria",
    tags: ["Classic", "African_literature", "Historical"],
    emoji: "",
    imageQuery: "classic novel book africa literature",
  },
  {
    id: "I_008",
    title: "Yellow Chilli Lekki",
    category: "Restaurant",
    description: "Upscale Nigerian restaurant known for peppersoup and grills",
    tags: ["Nigerian_cuisine", "Upscale", "Spicy"],
    emoji: "",
    imageQuery: "nigerian peppersoup restaurant upscale",
  },
  {
    id: "I_009",
    title: "Samsung Galaxy S24",
    category: "Product",
    description: "Samsung's latest flagship Android smartphone",
    tags: ["Tech", "Smartphone", "Android"],
    emoji: "",
    imageQuery: "samsung galaxy smartphone android",
  },
  {
    id: "I_010",
    title: "Burna Boy — I Told Them",
    category: "Music",
    description: "Grammy-winning Afrofusion album by Burna Boy",
    tags: ["Afrobeats", "Afrofusion", "Grammy"],
    emoji: "",
    imageQuery: "afrofusion album music grammy africa",
  },
  {
    id: "I_011",
    title: "Jollof Wars",
    category: "Movie",
    description: "A documentary about the great Nigerian vs Ghanaian jollof debate",
    tags: ["Nollywood", "Documentary", "Food"],
    emoji: "",
    imageQuery: "jollof rice documentary food nigeria",
  },
  {
    id: "I_012",
    title: "Nike Air Force 1",
    category: "Product",
    description: "Classic Nike sneakers — a streetwear staple",
    tags: ["Fashion", "Sneakers", "Classic"],
    emoji: "",
    imageQuery: "nike air force 1 sneakers white",
  },
];

// Reviews indexed by "userId_itemId"
export const MOCK_REVIEWS = {
  "U_amaka_I_001": {
    rating: 4.5,
    review_text:
      "Na real tasty jollof rice ohhh. E go make your taste bud happy. Five stars no be small thing — the portion size correct, service fast, and the fried plantain na level two. If you dey Lagos and you never chop here, abeg go. I no go lie to you.",
    adapter_used: "user_adapter",
    is_naija: true,
    inference_ms: 2100,
  },
  "U_amaka_I_002": {
    rating: 4.0,
    review_text:
      "Deep story wey go touch your heart. Adichie writing no dey play — every page na feeling. The family wahala realistic, the ending hit me hard. I don recommend am to three people already.",
    adapter_used: "user_adapter",
    is_naija: true,
    inference_ms: 1800,
  },
  "U_amaka_I_005": {
    rating: 4.8,
    review_text:
      "Abuja suya game strong! The pepper dey right, the meat fresh. I chop finish and I still dey think about am. This place na must-visit if you dey Abuja. No long talk — just go.",
    adapter_used: "user_adapter",
    is_naija: true,
    inference_ms: 1950,
  },
  "U_chidi_I_001": {
    rating: 3.5,
    review_text:
      "The ambiance is lacking and the presentation could be improved significantly. However, I must acknowledge that the flavour profile is genuinely authentic. The jollof rice had a proper smoky base. Service was average — we waited 25 minutes. Worth visiting once for the food alone.",
    adapter_used: "user_adapter",
    is_naija: false,
    inference_ms: 2300,
  },
  "U_chidi_I_002": {
    rating: 4.7,
    review_text:
      "Adichie's prose is masterful — every sentence layered with meaning. The exploration of religion and family dynamics is handled with extraordinary nuance. I found myself re-reading several chapters. One of the finest works of contemporary African literature.",
    adapter_used: "user_adapter",
    is_naija: false,
    inference_ms: 2100,
  },
  "U_john_I_004": {
    rating: 4.0,
    review_text:
      "Good product overall. The noise cancellation works well in office environments. Battery life is solid — I get about 5 hours per charge. A bit expensive but if you need reliable earphones for daily commuting, these are worth considering.",
    adapter_used: "user_adapter",
    is_naija: false,
    inference_ms: 1600,
  },
  "U_john_I_009": {
    rating: 4.2,
    review_text:
      "Solid Android phone. Camera is noticeably improved over last year. Performance is smooth for everyday tasks. Battery easily lasts a full day. Good value if you're in the Samsung ecosystem.",
    adapter_used: "user_adapter",
    is_naija: false,
    inference_ms: 1700,
  },
};

// Fallback review when a specific user+item combo is not in MOCK_REVIEWS
export function getDefaultMockReview(userId, itemId, isNaija) {
  if (isNaija) {
    return {
      rating: 4.0,
      review_text:
        "E dey okay sha. No be the best I don see but e get value for the money. Service dey fine, quality acceptable. I fit recommend am if you dey around the area.",
      adapter_used: "population_adapter",
      is_naija: true,
      inference_ms: 1900,
    };
  }
  return {
    rating: 3.8,
    review_text:
      "Decent overall. Not the best I have experienced but good value for the price. The quality is consistent and the service was acceptable. Would recommend to anyone in the area looking for a reliable option.",
    adapter_used: "population_adapter",
    is_naija: false,
    inference_ms: 1700,
  };
}

export const MOCK_CHAT_RESPONSES = [
  {
    agent_response:
      "Based on your taste, here are some correct spots for tonight! You tend to prefer local, affordable places with authentic flavours.",
    recommendations: [
      {
        rank: 1,
        item_id: "I_001",
        title: "Mama Put Lagos",
        twin_score: 4.5,
        explanation: "You love authentic local food and value for money.",
        category: "Restaurant",
        emoji: "",
      },
      {
        rank: 2,
        item_id: "I_005",
        title: "Buka Suya Spot",
        twin_score: 4.2,
        explanation: "Your past reviews show a strong preference for grilled meat.",
        category: "Restaurant",
        emoji: "",
      },
      {
        rank: 3,
        item_id: "I_008",
        title: "Yellow Chilli Lekki",
        twin_score: 4.0,
        explanation: "Spicy Nigerian cuisine matches your style perfectly.",
        category: "Restaurant",
        emoji: "",
      },
    ],
    intent: "discover",
    turn_count: 1,
  },
  {
    agent_response:
      "I found some great entertainment options that match your vibe. Here's what your twin thinks you'll enjoy:",
    recommendations: [
      {
        rank: 1,
        item_id: "I_006",
        title: "Omo Ghetto",
        twin_score: 4.3,
        explanation: "You enjoy Nigerian comedy and relatable storylines.",
        category: "Movie",
        emoji: "",
      },
      {
        rank: 2,
        item_id: "I_010",
        title: "Burna Boy — I Told Them",
        twin_score: 4.1,
        explanation: "Your music taste aligns strongly with Afrofusion.",
        category: "Music",
        emoji: "",
      },
      {
        rank: 3,
        item_id: "I_002",
        title: "Purple Hibiscus",
        twin_score: 3.9,
        explanation: "Nigerian literature you haven't explored yet.",
        category: "Book",
        emoji: "",
      },
    ],
    intent: "discover",
    turn_count: 2,
  },
];

export const MOCK_METRICS = {
  track_a: {
    rouge_l: 0.342,
    bertscore_f1: 0.871,
    rmse: 0.68,
    n_samples: 250,
    targets: { rouge_l: 0.3, bertscore_f1: 0.85, rmse: 0.8 },
  },
  track_b: {
    ndcg_10: 0.412,
    hit_rate_10: 0.534,
    cold_start_ndcg: 0.287,
    n_sessions: 20,
    targets: { ndcg_10: 0.35, hit_rate_10: 0.45 },
  },
};