// src/components/RecommendationCard.jsx
// ─────────────────────────────────────────────────────────────────
// Recommendation Card — used in the Twin Chat sidebar
//
// Props:
//   rec — { rank, item_id, title, twin_score, explanation, category, emoji }
// ─────────────────────────────────────────────────────────────────

import {
  Box,
  Text,
  Badge,
  HStack,
  VStack,
  useColorModeValue,
} from "@chakra-ui/react";
import { useNavigate } from "react-router-dom";
import StarRating from "./StarRating";

export default function RecommendationCard({ rec }) {
  const navigate = useNavigate();

  const cardBg      = useColorModeValue("white", "#1E1E1E");
  const borderColor = useColorModeValue("gray.200", "gray.700");
  const metaColor   = useColorModeValue("gray.500", "gray.400");

  return (
    <Box
      bg={cardBg}
      borderWidth="1px"
      borderColor={borderColor}
      borderRadius="xl"
      p={3}
      cursor="pointer"
      transition="all 0.2s"
      _hover={{
        shadow: "sm",
        borderColor: "brand.300",
        transform: "translateY(-1px)",
      }}
      onClick={() => navigate(`/item/${rec.item_id}`)}
      w="100%"
    >
      {/* Rank badge + category */}
      <HStack justify="space-between" mb={2}>
        <Badge
          colorScheme="brand"
          borderRadius="full"
          fontSize="10px"
          px={2}
        >
          #{rec.rank}
        </Badge>
        <Text fontSize="10px" color={metaColor}>
          {rec.category}
        </Text>
      </HStack>

      {/* Title with emoji */}
      <Text fontWeight="600" fontSize="sm" mb={1} noOfLines={1}>
        {rec.emoji} {rec.title}
      </Text>

      {/* Twin score as stars */}
      <StarRating rating={rec.twin_score} size="sm" />

      {/* Explanation */}
      <Text fontSize="xs" color={metaColor} mt={1} noOfLines={2} lineHeight="1.4">
        {rec.explanation}
      </Text>
    </Box>
  );
}