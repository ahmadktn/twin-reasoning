// src/components/Header.jsx
// ─────────────────────────────────────────────────────────────────
// Global Header — appears on every page
//
// Contains:
// - TwinReason logo (links to home)
// - Nav links: Feed, Twin Chat, Dashboard
// - User selector dropdown (changes global user)
// - Naija toggle (switches to Nigerian Pidgin)
// - Dark mode toggle
// ─────────────────────────────────────────────────────────────────

import {
  Box,
  Flex,
  Text,
  Select,
  Button,
  HStack,
  useColorMode,
  useColorModeValue,
} from "@chakra-ui/react";
import { MoonIcon, SunIcon } from "@chakra-ui/icons";
import { Link, useLocation } from "react-router-dom";
import { useApp } from "../context/AppContext";

export default function Header() {
  // colorMode = "light" or "dark"
  // toggleColorMode = function that switches between them
  const { colorMode, toggleColorMode } = useColorMode();

  // Colors that automatically switch between light and dark mode
  const bg         = useColorModeValue("white", "#1E1E1E");
  const border     = useColorModeValue("gray.200", "gray.700");
  const logoColor  = useColorModeValue("brand.500", "brand.300");

  // Global state from AppContext
  const { selectedUser, isNaija, changeUser, toggleLocale, allUsers } = useApp();

  // useLocation tells us the current URL so we can highlight the active nav link
  const location = useLocation();

  function isActive(path) {
    return location.pathname === path;
  }

  return (
    <Box
      as="header"
      bg={bg}
      borderBottom="1px solid"
      borderColor={border}
      px={6}
      py={3}
      position="sticky"
      top={0}
      zIndex={100}
      // Frosted glass effect — looks premium
      backdropFilter="blur(8px)"
      boxShadow="sm"
    >
      <Flex
        align="center"
        justify="space-between"
        maxW="1280px"
        mx="auto"
      >

        {/* ── LEFT: Logo + Nav Links ───────────────────────── */}
        <HStack spacing={8}>

          {/* Logo */}
          <Link to="/">
            <Text
              fontWeight="700"
              fontSize="xl"
              color={logoColor}
              letterSpacing="-0.5px"
            >
              TwinReason
            </Text>
          </Link>

          {/* Nav Links */}
          <HStack spacing={1}>
            <NavLink to="/"          label="Feed"       active={isActive("/")} />
            <NavLink to="/chat"      label="Twin Chat"  active={isActive("/chat")} />
            <NavLink to="/dashboard" label="My Twin"    active={isActive("/dashboard")} />
          </HStack>
        </HStack>

        {/* ── RIGHT: Controls ──────────────────────────────── */}
        <HStack spacing={3}>

          {/* User Selector Dropdown */}
          <Select
            size="sm"
            value={selectedUser.id}
            onChange={(e) => changeUser(e.target.value)}
            w="165px"
            borderRadius="lg"
            fontWeight="500"
            borderColor={border}
            _focus={{ borderColor: "brand.500", boxShadow: "0 0 0 1px #0F4C5C" }}
          >
            {allUsers.map((user) => (
              <option key={user.id} value={user.id}>
                {user.name}
              </option>
            ))}
          </Select>

          {/* Naija Toggle */}
          <Button
            size="sm"
            onClick={toggleLocale}
            borderRadius="full"
            fontWeight="600"
            fontSize="xs"
            px={4}
            // Orange when ON (matches accent colour from Figma guide)
            // Gray outline when OFF
            bg={isNaija ? "accent.500" : "transparent"}
            color={isNaija ? "white" : "gray.500"}
            border="1px solid"
            borderColor={isNaija ? "accent.500" : "gray.300"}
            _hover={{
              bg: isNaija ? "accent.600" : "gray.100",
            }}
          >
            🇳🇬 {isNaija ? "Naija ON" : "Naija OFF"}
          </Button>

          {/* Dark Mode Toggle */}
          <Button
            size="sm"
            onClick={toggleColorMode}
            variant="ghost"
            borderRadius="full"
            aria-label="Toggle dark mode"
          >
            {colorMode === "light" ? (
              <MoonIcon color="gray.500" />
            ) : (
              <SunIcon color="yellow.300" />
            )}
          </Button>

        </HStack>
      </Flex>
    </Box>
  );
}

// ── Sub-component: single nav link ───────────────────────────────
// Renders one navigation link with an underline when it's the active page
function NavLink({ to, label, active }) {
  const activeColor   = useColorModeValue("brand.500", "brand.300");
  const inactiveColor = useColorModeValue("gray.600", "gray.400");

  return (
    <Link to={to}>
      <Box
        px={3}
        py={2}
        fontSize="sm"
        fontWeight={active ? "600" : "400"}
        color={active ? activeColor : inactiveColor}
        borderBottom="2px solid"
        borderColor={active ? "brand.500" : "transparent"}
        transition="all 0.15s"
        _hover={{ color: activeColor }}
      >
        {label}
      </Box>
    </Link>
  );
}