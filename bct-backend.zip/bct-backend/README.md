# BCT Hackathon – FastAPI Backend

## Project Structure

```
bct-backend/
├── app/
│   ├── main.py               # FastAPI app + lifespan startup
│   ├── config.py             # All settings via pydantic-settings (.env)
│   ├── models.py             # Pydantic request/response schemas
│   ├── dependencies.py       # Data loading + FastAPI Depends() functions
│   ├── llm_provider.py       # Abstract LLM interface + OpenRouter/Anthropic/Local
│   ├── routes/
│   │   ├── personas.py       # GET /personas, GET /personas/{id}
│   │   ├── reviews.py        # POST /reviews/generate (SSE streaming)
│   │   ├── chat.py           # POST /chat/recommend (multi-turn)
│   │   ├── twins.py          # GET /twins/{id}  (Digital Twin page)
│   │   └── metrics.py        # GET /metrics
│   └── services/
│       ├── user_modeling.py  # Task A: predict rating + generate review + stream
│       └── recommendation.py # Task B: rank items, cold-start, multi-turn chat
├── data/                     # ← drop Kaggle exports here
│   ├── All_Beauty.jsonl      # raw reviews
│   ├── personas.json         # pre-built persona list
│   ├── user_profiles.json    # exported from Kaggle (optional; built from JSONL if missing)
│   └── metrics.json          # pre-computed evaluation metrics
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
└── .env.example
```

---

## Quick Start

```bash
cp .env.example .env          # fill in LLM_API_KEY
docker-compose up             # builds + runs on :8000
# OR without Docker:
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Docs → http://localhost:8000/docs

---

## LLM Provider

Edit `.env` to switch:

| Want | Config |
|------|--------|
| **OpenRouter** (default, free tier) | `LLM_PROVIDER=openrouter` `LLM_API_KEY=sk-or-...` |
| Anthropic Claude | `LLM_PROVIDER=anthropic` `LLM_API_KEY=sk-ant-...` |
| Local Mistral-7B (free, needs GPU) | `USE_LOCAL_LLM=true` |

OpenRouter gives you access to Mistral-7B-Instruct for free/cheap — same model used in the Kaggle notebook.

To add a new provider: subclass `LLMProvider` in `llm_provider.py`, implement `generate()` and `stream()`, add to factory.

---

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/personas` | List available personas |
| GET | `/personas/{id}` | Single persona summary |
| POST | `/reviews/generate` | **SSE stream** — reasoning + live tokens + result |
| POST | `/reviews/generate/sync` | Non-streaming fallback |
| POST | `/chat/recommend` | Multi-turn recommendation chat |
| GET | `/twins/{id}` | Full twin profile (Twin page) |
| GET | `/metrics` | Pre-computed evaluation metrics |

---

## Streaming Format (`POST /reviews/generate`)

Connect with `EventSource` on the frontend:

```javascript
const es = new EventSource("/reviews/generate");
es.onmessage = (e) => {
  const event = JSON.parse(e.data);
  if (event.type === "reasoning") showStep(event.step, event.text);
  if (event.type === "token")     appendToken(event.text);
  if (event.type === "result")    showFinal(event);
};
```

SSE event sequence:
```
{ "type": "reasoning", "step": 1, "text": "Loading persona..." }
{ "type": "reasoning", "step": 2, "text": "Analysing product..." }
{ "type": "reasoning", "step": 3, "text": "Calibrating 5-star review style..." }
{ "type": "token",     "text": "Chai! " }
{ "type": "token",     "text": "This product..." }
...
{ "type": "result",    "rating": 5, "review": "Chai! This product na original...", "confidence": 0.95 }
```

---

## Kaggle → Backend Data Sync

| Kaggle export | Drop here | Used by |
|---------------|-----------|---------|
| `user_profiles.json` | `data/user_profiles.json` | All routes (personas, reviews, chat, twins) |
| `personas.json` (curated list) | `data/personas.json` | `GET /personas` |
| `final_metrics_complete.json` | `data/metrics.json` | `GET /metrics` |
| `All_Beauty.jsonl` | `data/All_Beauty.jsonl` | Profile builder fallback + item profiles |

If `user_profiles.json` is missing, profiles are built from the raw JSONL on startup (slower).

---

## Adding Features

| Feature | Where |
|---------|-------|
| LangChain | `app/services/` — replace `llm.generate()` with a chain |
| Vector DB (Pinecone/Qdrant) | `app/dependencies.py` — add client on startup; inject via Depends |
| New dataset | Drop in `data/`, update `DATASET_PATH` in `.env` |
| New LLM provider | Subclass `LLMProvider` in `llm_provider.py`, add to factory |
| Redis caching | Wrap `@lru_cache` functions in `dependencies.py` |

---

## Deploy to Railway

```bash
# 1. Push to GitHub
# 2. Connect Railway to repo
# 3. Set env vars in Railway dashboard (LLM_API_KEY etc.)
# Done — auto-deploys on push
```
