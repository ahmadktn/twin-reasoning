"""
app/main.py — FastAPI entry point.
Run: uvicorn app.main:app --reload
Docs: http://localhost:8000/docs
"""
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings
from app.dependencies import load_user_profiles, load_item_profiles
from app.routes import personas, reviews, chat, twins, metrics


@asynccontextmanager
async def lifespan(app: FastAPI):
    print("[startup] Pre-loading data caches...")
    load_user_profiles()
    load_item_profiles()
    print("[startup] Ready.")
    yield


app = FastAPI(
    title=settings.APP_TITLE,
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(personas.router)
app.include_router(reviews.router)
app.include_router(chat.router)
app.include_router(twins.router)
app.include_router(metrics.router)


@app.get("/", tags=["Health"])
def root():
    return {
        "status": "ok",
        "llm_backend": "local" if settings.USE_LOCAL_LLM else settings.LLM_PROVIDER,
        "model": settings.LOCAL_MODEL_NAME if settings.USE_LOCAL_LLM else settings.LLM_MODEL,
    }
