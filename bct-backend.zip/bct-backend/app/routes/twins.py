"""
app/routes/twins.py
GET /twins/{persona_id}  — full twin profile for the "Digital Twin" page.
"""
from fastapi import APIRouter, Depends, HTTPException
from app.dependencies import get_profiles

router = APIRouter(prefix="/twins", tags=["Digital Twins"])


@router.get("/{persona_id}")
def get_twin(persona_id: str, profiles: dict = Depends(get_profiles)):
    """
    Full twin profile — used by the frontend Twin page.
    Returns enough data to render a persona card with review history stats.
    """
    if persona_id not in profiles:
        raise HTTPException(404, f"Twin {persona_id} not found")

    p = profiles[persona_id]
    return {
        "id": persona_id,
        "avg_rating": round(p["avg_rating"], 2),
        "num_reviews": p["num_reviews"],
        "rating_std": round(p.get("rating_std", 0.0), 2),
        "rating_distribution": p["rating_distribution"],
        "review_samples": p.get("review_samples", [])[:3],
        "products_reviewed_count": len(p.get("products_reviewed", [])),
        "top_products": p.get("products_reviewed", [])[:5],
    }
