"""
app/routes/chat.py
POST /chat/recommend  — multi-turn recommendation chat (Task B).
"""
from fastapi import APIRouter, Depends, HTTPException
import pandas as pd

from app.dependencies import get_llm, get_profiles, get_item_data, get_reviews
from app.llm_provider import LLMProvider
from app.models import ChatRequest, ChatResponse, Recommendation
from app.services.recommendation import multi_turn_recommend, cold_start

router = APIRouter(prefix="/chat", tags=["Chat – Task B"])


@router.post("/recommend", response_model=ChatResponse)
async def recommend(
    req: ChatRequest,
    profiles: dict = Depends(get_profiles),
    item_profiles: dict = Depends(get_item_data),
    df: pd.DataFrame = Depends(get_reviews),
    llm: LLMProvider = Depends(get_llm),
):
    """
    Multi-turn recommendation chat.
    Pass the full message history each request (stateless).
    Returns assistant reply + ranked recommendations.
    """
    if req.persona_id not in profiles:
        raise HTTPException(404, f"Persona {req.persona_id} not found")

    profile = profiles[req.persona_id]
    history = set(profile.get("products_reviewed", []))
    candidates = [p for p in df["parent_asin"].unique() if p not in history]

    if len(candidates) < 5 or profile["num_reviews"] <= 2:
        recs = cold_start(df, top_k=req.top_k)
        reply = "Omo! Based on what's popular, here are some great picks for you:"
    else:
        messages = [m.model_dump() for m in req.messages]
        reply, recs = await multi_turn_recommend(
            profile, messages, candidates, item_profiles, llm, req.top_k
        )

    return ChatResponse(
        reply=reply,
        recommendations=[Recommendation(**r) for r in recs],
    )
