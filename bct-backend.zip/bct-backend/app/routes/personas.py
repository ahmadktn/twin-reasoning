from fastapi import APIRouter, Depends, HTTPException
from typing import List, Dict
from app.dependencies import get_personas_data, get_profiles
from app.models import Persona

router = APIRouter(prefix="/personas", tags=["Personas"])


@router.get("", response_model=List[Dict])
def list_personas(personas: List[Dict] = Depends(get_personas_data)):
    """List all available personas (pre-exported from Kaggle)."""
    return personas


@router.get("/{persona_id}")
def get_persona(persona_id: str, profiles: Dict = Depends(get_profiles)):
    """Get persona details. Also used by the Twin page."""
    if persona_id not in profiles:
        raise HTTPException(404, f"Persona {persona_id} not found")
    p = profiles[persona_id]
    return {
        "id": persona_id,
        "avg_rating": round(p["avg_rating"], 2),
        "num_reviews": p["num_reviews"],
        "rating_distribution": p["rating_distribution"],
        "review_style": " ".join(p.get("review_samples", [])[:1])[:200],
        "products_reviewed_count": len(p.get("products_reviewed", [])),
    }
