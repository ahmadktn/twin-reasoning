"""
app/dependencies.py
All heavy data loading happens here once at startup.
Routes inject what they need via FastAPI Depends — nothing loads twice.
"""
import json
import os
import pandas as pd
from functools import lru_cache
from typing import Dict, List
from app.config import settings
from app.llm_provider import get_llm_provider, LLMProvider


# ── Data loaders ───────────────────────────────────────────────────────────────

@lru_cache(maxsize=1)
def load_reviews_df() -> pd.DataFrame:
    df = pd.read_json(settings.DATASET_PATH, lines=True)
    df["rating"] = pd.to_numeric(df["rating"], errors="coerce")
    return df


@lru_cache(maxsize=1)
def load_personas() -> List[Dict]:
    path = os.path.join(settings.DATA_DIR, "personas.json")
    if not os.path.exists(path):
        return []
    with open(path) as f:
        return json.load(f)


@lru_cache(maxsize=1)
def load_user_profiles() -> Dict:
    path = os.path.join(settings.DATA_DIR, "user_profiles.json")
    if not os.path.exists(path):
        # Build from raw dataset if pre-export not available
        from app.services.user_modeling import build_profiles
        return build_profiles(load_reviews_df())
    with open(path) as f:
        return json.load(f)


@lru_cache(maxsize=1)
def load_item_profiles() -> Dict:
    from app.services.recommendation import build_item_profiles
    return build_item_profiles(load_reviews_df())


@lru_cache(maxsize=1)
def load_metrics() -> Dict:
    path = os.path.join(settings.DATA_DIR, "metrics.json")
    if not os.path.exists(path):
        return {}
    with open(path) as f:
        return json.load(f)


# ── FastAPI dependency functions ───────────────────────────────────────────────
# Use these with Depends() in routes.

def get_llm() -> LLMProvider:
    return get_llm_provider()


def get_profiles() -> Dict:
    return load_user_profiles()


def get_item_data() -> Dict:
    return load_item_profiles()


def get_reviews() -> pd.DataFrame:
    return load_reviews_df()


def get_personas_data() -> List[Dict]:
    return load_personas()


def get_metrics_data() -> Dict:
    return load_metrics()
